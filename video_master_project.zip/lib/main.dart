import 'package:flutter/material.dart';
import 'screens/home.dart';
import 'screens/downloads.dart';
import 'screens/settings.dart';

void main() {
  runApp(VideoMasterApp());
}

class VideoMasterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Video Master',
      theme: ThemeData(
        primaryColor: Colors.red,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
      ),
      home: HomeScreen(),
    );
  }
}
