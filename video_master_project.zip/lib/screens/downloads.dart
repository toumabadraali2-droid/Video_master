import 'package:flutter/material.dart';

class DownloadsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Téléchargements"),
      ),
      body: Center(
        child: Text(
          "Aucun téléchargement pour le moment",
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
