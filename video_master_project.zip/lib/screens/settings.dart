import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Paramètres"),
      ),
      body: ListView(
        children: [
          ListTile(
            title: Text("À propos"),
            subtitle: Text("© 2025 VideoMaster — Tous droits réservés"),
          ),
        ],
      ),
    );
  }
}
