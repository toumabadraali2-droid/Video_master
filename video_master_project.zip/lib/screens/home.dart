import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Video Master"),
      ),
      body: Center(
        child: Text(
          "Accueil — Coller un lien pour télécharger",
          style: TextStyle(fontSize: 18),
        ),
      ),
    );
  }
}
